<?php

namespace enrol_arlo\Arlo\AuthAPI\Resource;

/**
 * Class DestinationContactInfo
 * @package enrol_arlo\Arlo\AuthAPI\Resource
 */
class DestinationContactInfo extends ContactInfo {}